#!/bin/sh

launched_by_user=0
registriesDirectoryPath=""

# 检查参数个数
if [ $# -eq 0 ]; then
    launched_by_user=1
else
    launched_by_user=0
    registriesDirectoryPath=$1
fi

kGetRegistriesDirectoryPathErrorCode=-1;
kGetMathCaptureRegFilePathErrorCode=-2;
kOldMathCaptureRegFileExistsErrorCode=-3;
kCopyInstallMathCaptureRegFileErrorCode=-4;
kChmodInstallMathCaptureRegFileErrorCode=-5;
kCreateMathCapturePluginDirectoryErrorCode=-6;
kGetMathCapturePluginFilePathErrorCode=-7;
kOldMathCapturePluginFileExistsErrorCode=-8;
kCopyMathCapturePluginBundleFileErrorCode=-9;
kGetMathCaptureAddInFilePathErrorCode=-10;
kOldMathCaptureAddInFileExistsErrorCode=-11;
kCopyMathCaptureAddInBundleFileErrorCode=-12;

# 1. 检查MathCapture是否已经安装
if [ $launched_by_user -eq 1 ]; then
    if [ -d "/Applications/MathCapture.app" ]; then
        echo "MathCapture 已安装。"
    else
        echo "MathCapture 未安装。请确保已经安装 MathCapture 。"
        exit 1
    fi
fi

# 2. 检查Microsoft PowerPoint 365是否已安装
if [ $launched_by_user -eq 1 ]; then
    if [ -d "/Applications/Microsoft PowerPoint.app" ]; then
        echo "Microsoft PowerPoint 365 已安装。"
        powerPointBundlePath="/Applications/Microsoft PowerPoint.app"
    else
        echo "Microsoft PowerPoint 365 未安装。请确保已经安装 Microsoft PowerPoint 。"
        exit 2
    fi
fi

# 3. 安装注册表
# 3.1 获取注册表安装目录的路径
if [ $launched_by_user -eq 1 ]; then
    registriesDirectoryPath="${powerPointBundlePath}/Contents/SharedSupport/Registries"
fi
# 3.2 检查安装目录是否存在
if [ ! -d "${registriesDirectoryPath}" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kGetRegistriesDirectoryPathErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kGetRegistriesDirectoryPathErrorCode}
fi

# 3.3 获取注册表文件
MathCaptureRegFilePath="$(dirname "$0")/PowerPoint/MathCapture.reg"
if [ ! -f "$MathCaptureRegFilePath" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kGetMathCaptureRegFilePathErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kGetMathCaptureRegFilePathErrorCode}
fi

# 3.4 获取注册表待安装的路径
MathCaptureRegFileInstallPath="${registriesDirectoryPath}/MathCapture.reg"
if [ -f "$MathCaptureRegFileInstallPath" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。卸载过程未成功完成。在继续操作之前，请先卸载相关插件。错误代码：${kOldMathCaptureRegFileExistsErrorCode}。"
    exit ${kOldMathCaptureRegFileExistsErrorCode}
fi

# 3.5 拷贝注册表
sudo cp "${MathCaptureRegFilePath}" "${MathCaptureRegFileInstallPath}";
if [ ! $? -eq 0 ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kCopyInstallMathCaptureRegFileErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kCopyInstallMathCaptureRegFileErrorCode}
fi

sudo chmod 775 "${MathCaptureRegFileInstallPath}"
if [ ! $? -eq 0 ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kChmodInstallMathCaptureRegFileErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kChmodInstallMathCaptureRegFileErrorCode}
fi

# 4. 安装插件

# 4.1 获取插件安装目录的路径
pluginDictoryPath="/Library/Application Support/Microsoft/Office365/User Content.localized/Startup.localized/PowerPoint/"
if [ ! -d "${pluginDictoryPath}" ]; then
    sudo mkdir -p "${pluginDictoryPath}"
    if [ ! $? -eq 0 ]; then
        echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kCreateMathCapturePluginDirectoryErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
        exit ${kCreateMathCapturePluginDirectoryErrorCode}
    fi
fi

# 4.2 获取插件文件
MathCapturePluginBundleFilePath="$(dirname "$0")/PowerPoint/MathCaptureHelper.bundle"
if [ ! -d "$MathCapturePluginBundleFilePath" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kGetMathCapturePluginFilePathErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kGetMathCapturePluginFilePathErrorCode}
fi

# 4.3 获取插件待安装的路径
MathCapturePluginBundleFileInstallPath="${pluginDictoryPath}/MathCaptureHelper.bundle"
if [ -d "$MathCapturePluginBundleFileInstallPath" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。卸载过程未成功完成。在继续操作之前，请先卸载相关插件。错误代码：${kOldMathCapturePluginFileExistsErrorCode}。"
    exit ${kOldMathCapturePluginFileExistsErrorCode}
fi

# 4.3 拷贝插件
sudo cp -R "${MathCapturePluginBundleFilePath}" "${MathCapturePluginBundleFileInstallPath}";
if [ ! $? -eq 0 ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kCopyMathCapturePluginBundleFileErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kCopyMathCapturePluginBundleFileErrorCode}
fi

# 5. 安装PowerPoint加载项
# 5.1 获取加载项文件
MathCaptureAddInFilePath="$(dirname "$0")/PowerPoint/MathCaptureHelper.ppam"
if [ ! -f "$MathCaptureAddInFilePath" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kGetMathCaptureAddInFilePathErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kGetMathCaptureAddInFilePathErrorCode}
fi

# 5.2 获取加载项待安装的路径
MathCaptureAddInFileInstallPath="${pluginDictoryPath}/MathCaptureHelper.ppam"
if [ -f "$MathCaptureAddInFileInstallPath" ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。卸载过程未成功完成。在继续操作之前，请先卸载相关插件。错误代码：${kOldMathCaptureAddInFileExistsErrorCode}。"
    exit ${kOldMathCaptureAddInFileExistsErrorCode}
fi

# 5.3 拷贝加载项
sudo cp -R "${MathCaptureAddInFilePath}" "${MathCaptureAddInFileInstallPath}";
if [ ! $? -eq 0 ]; then
    echo "未能成功为 Microsoft PowerPoint 安装 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kCopyMathCaptureAddInBundleFileErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
    exit ${kCopyMathCaptureAddInBundleFileErrorCode}
fi

echo "成功为 Microsoft PowerPoint 安装 MathCapture 插件。"
exit 0