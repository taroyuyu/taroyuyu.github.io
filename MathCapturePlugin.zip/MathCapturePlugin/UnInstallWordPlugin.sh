#!/bin/sh

launched_by_user=0
registriesDirectoryPath=""

# 检查参数个数
if [ $# -eq 0 ]; then
    launched_by_user=1
else
    launched_by_user=0
    registriesDirectoryPath=$1
fi

kUninstallMathCaptureRegFileErrorCode=-101;
kUninstallMathCapturePluginFileErrorCode=-102;

# 1. 检查Microsoft Word 365是否已安装
if [ $launched_by_user -eq 1 ]; then
    if [ -d "/Applications/Microsoft Word.app" ]; then
        wordBundlePath="/Applications/Microsoft Word.app"
    else
        echo "成功为 Microsoft Word 卸载 MathCapture 插件"
        exit 0
    fi
fi

# 2. 卸载注册表
MathCaptureRegFileInstallPath="${wordBundlePath}/Contents/SharedSupport/Registries/MathCapture.reg"
if [ -f "$MathCaptureRegFileInstallPath" ]; then #注册表存在
    sudo rm -rf "${MathCaptureRegFileInstallPath}"
    if [ ! $? -eq 0 ]; then
        echo "未能成功为 Microsoft Word 卸载 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kUninstallMathCaptureRegFileErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
        exit ${kUninstallMathCaptureRegFileErrorCode}
    fi
fi

# 3. 卸载插件
pluginFilePath="/Library/Application Support/Microsoft/Office365/User Content.localized/Startup.localized/Word/MathCaptureWordHelper.bundle"
if [ -d "$pluginFilePath" ]; then #插件存在
    sudo rm -rf "${pluginFilePath}"
    if [ ! $? -eq 0 ]; then
        echo "未能成功为 Microsoft Word 卸载 MathCapture 插件。发生了一个意外的内部错误。错误代码：${kUninstallMathCapturePluginFileErrorCode}。请稍后再试，如果问题持续存在，请联系支持团队。"
        exit ${kUninstallMathCapturePluginFileErrorCode}
    fi
fi

echo "成功为 Microsoft Word 卸载 MathCapture 插件。"
exit 0